# test_sklearn1
使用sklearn做线性回归，并作图表达，内蒙古碳排放指标统计数据
